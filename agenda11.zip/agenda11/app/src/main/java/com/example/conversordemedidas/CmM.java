package com.example.conversordemedidas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CmM extends AppCompatActivity {
    EditText edtM4Prog;
    EditText edtCm2Prog;
    Button btnConverterCmMProg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cm_m);

        edtM4Prog = (EditText) findViewById(R.id.edtM4);
        edtCm2Prog = (EditText) findViewById(R.id.edtCm2);
        btnConverterCmMProg = (Button) findViewById(R.id.btnConverterCmM);

        btnConverterCmMProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float cm = Float.parseFloat(edtCm2Prog.getText().toString());
                float m = cm/1000;
                edtM4Prog.setText(String.valueOf(m));
            }
        });

    }
}