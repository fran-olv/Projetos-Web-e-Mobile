package com.example.conversordemedidas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MCm extends AppCompatActivity {
    EditText getEdtM3Prog;
    EditText edtCmProg;
    Button btnConverterMCmProg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mcm);

        getEdtM3Prog = (EditText) findViewById(R.id.edtM3);
        edtCmProg = (EditText) findViewById(R.id.edtCm);
        btnConverterMCmProg = (Button) findViewById(R.id.btnConverterMCm);

        btnConverterMCmProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float m = Float.parseFloat(getEdtM3Prog.getText().toString());
                float cm = m*1000;
                edtCmProg.setText(String.valueOf(cm));
            }
        });

    }
}