package com.example.conversordemedidas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnKmMProg, btnMKmProg, btnMcmProg, btnCmMProg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnKmMProg = (Button) findViewById(R.id.btnKmM);
        btnKmMProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, KmM.class);
                startActivity(it);
            }
        });

        btnMKmProg = (Button) findViewById(R.id.btnMKm);
        btnMKmProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, MKm.class);
                startActivity(it);

            }
        });

        btnMcmProg = (Button) findViewById(R.id.btnMCm);
        btnMcmProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, MCm.class);
                startActivity(it);
            }
        });


        btnCmMProg = (Button) findViewById(R.id.btnCmM);
        btnCmMProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, CmM.class);
                startActivity(it);
            }
        });
    }
}