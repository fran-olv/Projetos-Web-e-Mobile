package com.example.conversordemedidas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class KmM extends AppCompatActivity {

    EditText edtKmProg;
    EditText edtMProg;

    EditText getEdtKmProg;
    Button btnConverterKmMProg;
    Button btnNovoProg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_km_m);

        edtKmProg = (EditText) findViewById(R.id.edtKM);
        edtMProg = (EditText) findViewById(R.id.edtM);
        btnConverterKmMProg = (Button) findViewById(R.id.btnConverterKmM);

        btnConverterKmMProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float km = Float.parseFloat(edtKmProg.getText().toString());
                float m = km/1000;
                edtMProg.setText(String.valueOf(m));
            }
        });

    }
}