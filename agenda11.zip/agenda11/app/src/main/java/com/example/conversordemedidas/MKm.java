package com.example.conversordemedidas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MKm extends AppCompatActivity {

    EditText edtKm2Prog;
    EditText edtM2Prog;
    Button btnConverterMKmProg;
    Button btnNovoProg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mkm);

        edtKm2Prog = (EditText) findViewById(R.id.edtKM2);
        edtM2Prog = (EditText) findViewById(R.id.edtM2);
        btnConverterMKmProg = (Button) findViewById(R.id.btnConverterMKm);

        btnConverterMKmProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float m = Float.parseFloat(edtM2Prog.getText().toString());
                float km = m*1000;
                edtKm2Prog.setText(String.valueOf(km));
            }
        });
    }
}