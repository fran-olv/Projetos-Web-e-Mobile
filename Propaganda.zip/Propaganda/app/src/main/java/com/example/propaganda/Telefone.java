package com.example.propaganda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Telefone extends AppCompatActivity {
    Button btnTelProg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telefone);

        btnTelProg = (Button) findViewById(R.id.btnTel);

        btnTelProg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Telefone.this, MainActivity.class);
                startActivity(it);
            }
        });
    }
}